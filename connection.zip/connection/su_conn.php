<?php
include_once ("ez_sql_core.php");
include_once ("ez_sql_mysqli.php");

$dbmysql = new ezSQL_mysqli('root','','bouba_db','localhost');
?>